\# ITF Python Yönetim Sistemi



\## Özellikler

\- Personel yönetimi

\- Cihaz takibi

\- RKE muayene sistemi



\## Gereksinimler

\- Python 3.9+

\- Google Cloud Console projesi

\- Gerekli kütüphaneler (bkz. requirements.txt)



\## Kurulum

1\. `pip install -r requirements.txt`

2\. Google API credentials yapılandırması

3\. `python main.py`



\## Kullanım

...

